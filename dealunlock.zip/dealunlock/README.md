# DealUnlock

موقع اشتراك شهري ($10) للوصول لقائمة يومية مُنسّقة ومُتحقق منها من أقوى
الخصومات الحقيقية على Amazon و AliExpress و Shein و Booking.

**الموديل:** عينة مجانية كاملة تشوفها بدون دفع + قائمة كاملة مقفولة تُفتح
بالاشتراك عبر Lemon Squeezy. لا يوجد "حجب رابط عام" — القيمة المدفوعة هي
البحث والتحقق والتنسيق اليومي.

---

## 1. الإعداد على Lemon Squeezy

1. أنشئ **Store** إن ما عندك واحد.
2. أنشئ **Product** من نوع اشتراك (Subscription) بسعر $10/شهرياً، وخذ الـ
   **Variant ID** بتاعه.
3. من إعدادات الـ Store خذ الـ **Store ID**.
4. من Settings → API خذ **API Key**.
5. من Settings → Webhooks:
   - أنشئ Webhook جديد، الرابط: `https://your-app.vercel.app/api/webhook`
   - فعّل الأحداث: `subscription_created`, `subscription_updated`,
     `subscription_cancelled`, `subscription_expired`, `subscription_payment_success`
   - خذ الـ **Signing Secret** وحطه بـ `LEMONSQUEEZY_WEBHOOK_SECRET`

---

## 2. رفع المشروع لـ GitHub من الجوال

أسهل طريقة بدون تثبيت أي شي على الجوال:

1. افتح **github.com** من متصفح الجوال وسجل دخول.
2. أنشئ **repository** جديد اسمه `dealunlock`.
3. استخدم خاصية **"Upload files"** بصفحة الـ repo وارفع كل الملفات
   والمجلدات (تقدر تضغطها بملف zip وترفعه، GitHub يفك الضغط تلقائياً لو
   رفعته بطريقة "Add file → Upload files" بعد فك الضغط محلياً، أو استخدم
   تطبيق مثل **Working Copy** (iOS) أو **Termux + git** (Android) لو تبي
   تحكم أدق بالـ git من الجوال مباشرة).

بديل أسهل: نزّل تطبيق **GitHub Mobile** أو استخدم متصفح الجوال مباشرة —
كلاهما يدعم رفع ملفات وإنشاء commits بدون كمبيوتر.

---

## 3. النشر على Vercel

1. افتح **vercel.com** من الجوال وسجل دخول بحساب GitHub.
2. اضغط **New Project** واختر الـ repo `dealunlock`.
3. قبل الضغط على Deploy، أضف متغيرات البيئة (Environment Variables) من
   ملف `.env.example`:
   - `LEMONSQUEEZY_API_KEY`
   - `LEMONSQUEEZY_STORE_ID`
   - `LEMONSQUEEZY_VARIANT_ID`
   - `LEMONSQUEEZY_WEBHOOK_SECRET`
   - `NEXT_PUBLIC_URL` (حط رابط Vercel اللي راح يطلع لك، تقدر تحدّثه بعد أول نشر)
4. اضغط **Deploy**.

## 4. تفعيل قاعدة البيانات (Vercel Postgres)

1. من داشبورد المشروع على Vercel → تبويب **Storage** → **Create Database**
   → اختر **Postgres**.
2. Vercel بيضيف `DATABASE_URL` تلقائياً لمتغيرات البيئة.
3. أعد النشر (Redeploy) عشان يلتقط المتغير الجديد.

> ملاحظة: بدون `DATABASE_URL` الموقع يشتغل محلياً فقط بقاعدة بيانات SQLite
> محلية (`dev.db`) — هذي لا تصلح للإنتاج على Vercel لأن نظام الملفات مؤقت.
> لازم تفعّل Postgres قبل النشر النهائي.

---

## 5. تحديث القائمة يومياً

القائمة حالياً بملف `lib/deals.ts` — عدّل عليه مباشرة (أضف/احذف/غيّر خصومات)
وارفع commit جديد، Vercel ينشر تلقائياً. لاحقاً تقدر تحوّلها لمصدر بيانات
خارجي (Google Sheet، API، إلخ) بدون ما تغيّر باقي الكود.

---

## الأمان

- توقيع الـ Webhook يُتحقق منه بـ HMAC SHA256 قبل أي معالجة.
- لا تُسجَّل أي بيانات شخصية (إيميلات) بالـ logs.
- الروابط المباشرة لا تظهر إلا لمشترك فعّال (يُتحقق منه بقاعدة البيانات
  بكل طلب، مو بمجرد كوكيز).
