// lib/deals.ts
// بيانات الخصومات — mock مبدئياً. لاحقاً تقدر تربطها بمصدر حقيقي (API / scraping يدوي / إدخال يدوي).
// كل خصم له حقل `free`: لو true يظهر للجميع كعينة، لو false يظهر فقط للمشتركين الفعّالين.

export type Deal = {
  id: string;
  title: string;
  store: "Amazon" | "AliExpress" | "Shein" | "Booking";
  originalPrice: number;
  discountedPrice: number;
  currency: string;
  imageUrl: string;
  directUrl: string; // الرابط المباشر — لا يُعرض في الواجهة إلا حسب صلاحية العرض (free / subscriber)
  free: boolean;
  updatedAt: string; // ISO date
};

export const deals: Deal[] = [
  {
    id: "d001",
    title: "Wireless Noise-Cancelling Headphones",
    store: "Amazon",
    originalPrice: 199,
    discountedPrice: 89,
    currency: "USD",
    imageUrl: "https://placehold.co/400x300?text=Headphones",
    directUrl: "https://www.amazon.com/dp/EXAMPLE001",
    free: true,
    updatedAt: "2026-09-15",
  },
  {
    id: "d002",
    title: "Smart Fitness Watch Series 5",
    store: "AliExpress",
    originalPrice: 65,
    discountedPrice: 22,
    currency: "USD",
    imageUrl: "https://placehold.co/400x300?text=Smart+Watch",
    directUrl: "https://www.aliexpress.com/item/EXAMPLE002.html",
    free: true,
    updatedAt: "2026-09-15",
  },
  {
    id: "d003",
    title: "Boho Summer Dress Collection",
    store: "Shein",
    originalPrice: 45,
    discountedPrice: 14,
    currency: "USD",
    imageUrl: "https://placehold.co/400x300?text=Summer+Dress",
    directUrl: "https://www.shein.com/EXAMPLE003.html",
    free: false,
    updatedAt: "2026-09-15",
  },
  {
    id: "d004",
    title: "4-Star Beach Resort — 3 Nights",
    store: "Booking",
    originalPrice: 480,
    discountedPrice: 210,
    currency: "USD",
    imageUrl: "https://placehold.co/400x300?text=Beach+Resort",
    directUrl: "https://www.booking.com/hotel/EXAMPLE004.html",
    free: false,
    updatedAt: "2026-09-15",
  },
  {
    id: "d005",
    title: "Robot Vacuum Cleaner Pro",
    store: "Amazon",
    originalPrice: 350,
    discountedPrice: 149,
    currency: "USD",
    imageUrl: "https://placehold.co/400x300?text=Robot+Vacuum",
    directUrl: "https://www.amazon.com/dp/EXAMPLE005",
    free: false,
    updatedAt: "2026-09-15",
  },
  {
    id: "d006",
    title: "Men's Winter Jacket Bundle",
    store: "AliExpress",
    originalPrice: 80,
    discountedPrice: 27,
    currency: "USD",
    imageUrl: "https://placehold.co/400x300?text=Winter+Jacket",
    directUrl: "https://www.aliexpress.com/item/EXAMPLE006.html",
    free: false,
    updatedAt: "2026-09-15",
  },
];

export function getFreeDeals(): Deal[] {
  return deals.filter((d) => d.free);
}

export function getAllDeals(): Deal[] {
  return deals;
}
