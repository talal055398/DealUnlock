// lib/db.ts
// طبقة قاعدة بيانات بسيطة جداً — بدون ORM.
// - في التطوير المحلي (بدون DATABASE_URL): تستخدم SQLite ملف محلي (dev.db).
// - في الإنتاج على Vercel (مع DATABASE_URL): تستخدم Vercel Postgres.
//
// جدول واحد فقط: subscribers
// نخزن حالة الاشتراك بالإيميل، مربوطة بـ subscription_id من Lemon Squeezy.

export type Subscriber = {
  email: string;
  subscription_id: string;
  status: "active" | "cancelled" | "expired" | "past_due";
  renews_at: string | null;
  created_at: string;
  updated_at: string;
};

const isProd = !!process.env.DATABASE_URL;

// ---------- Postgres (إنتاج) ----------
async function pgQuery(sql: string, params: any[] = []) {
  const { sql: vercelSql } = await import("@vercel/postgres");
  return vercelSql.query(sql, params);
}

async function ensureTablePg() {
  await pgQuery(`
    CREATE TABLE IF NOT EXISTS subscribers (
      email TEXT PRIMARY KEY,
      subscription_id TEXT UNIQUE NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      renews_at TIMESTAMP,
      created_at TIMESTAMP DEFAULT NOW(),
      updated_at TIMESTAMP DEFAULT NOW()
    );
  `);
}

// ---------- SQLite (تطوير محلي) ----------
let sqliteDb: any = null;
function getSqlite() {
  if (sqliteDb) return sqliteDb;
  // استيراد ديناميكي حتى لا يفشل البناء على بيئات بدون better-sqlite3
  const Database = require("better-sqlite3");
  sqliteDb = new Database("dev.db");
  sqliteDb.exec(`
    CREATE TABLE IF NOT EXISTS subscribers (
      email TEXT PRIMARY KEY,
      subscription_id TEXT UNIQUE NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      renews_at TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);
  return sqliteDb;
}

// ---------- واجهة موحدة ----------

export async function upsertSubscriber(data: {
  email: string;
  subscription_id: string;
  status: Subscriber["status"];
  renews_at: string | null;
}) {
  if (isProd) {
    await ensureTablePg();
    await pgQuery(
      `INSERT INTO subscribers (email, subscription_id, status, renews_at, updated_at)
       VALUES ($1, $2, $3, $4, NOW())
       ON CONFLICT (email) DO UPDATE SET
         subscription_id = EXCLUDED.subscription_id,
         status = EXCLUDED.status,
         renews_at = EXCLUDED.renews_at,
         updated_at = NOW();`,
      [data.email, data.subscription_id, data.status, data.renews_at]
    );
  } else {
    const db = getSqlite();
    db.prepare(
      `INSERT INTO subscribers (email, subscription_id, status, renews_at, updated_at)
       VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
       ON CONFLICT(email) DO UPDATE SET
         subscription_id = excluded.subscription_id,
         status = excluded.status,
         renews_at = excluded.renews_at,
         updated_at = CURRENT_TIMESTAMP;`
    ).run(data.email, data.subscription_id, data.status, data.renews_at);
  }
}

export async function getSubscriberByEmail(
  email: string
): Promise<Subscriber | null> {
  if (isProd) {
    await ensureTablePg();
    const result = await pgQuery(
      `SELECT * FROM subscribers WHERE email = $1 LIMIT 1;`,
      [email]
    );
    return (result.rows[0] as Subscriber) || null;
  } else {
    const db = getSqlite();
    const row = db
      .prepare(`SELECT * FROM subscribers WHERE email = ? LIMIT 1;`)
      .get(email);
    return (row as Subscriber) || null;
  }
}

// اشتراك فعّال = status active وما زال renews_at (أو بدون تاريخ انتهاء معروف) في المستقبل أو غير محدد
export function isActiveSubscriber(sub: Subscriber | null): boolean {
  if (!sub) return false;
  if (sub.status !== "active") return false;
  if (sub.renews_at) {
    return new Date(sub.renews_at).getTime() > Date.now();
  }
  return true;
}
