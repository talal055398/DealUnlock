# خريطة المشروع

```
app/
  layout.tsx                     ← Layout عام (RTL + عنوان الموقع)
  globals.css                    ← استيراد Tailwind
  page.tsx                       ← الصفحة الرئيسية: عينة مجانية + قائمة مقفولة
                                    + نموذج تحقق من الاشتراك + زر اشتراك
  success/page.tsx                ← تظهر بعد الدفع، توجّه المستخدم يتحقق بإيميله
  api/
    checkout/route.ts             ← POST: ينشئ جلسة Lemon Squeezy Checkout
                                     (اشتراك، مو دفعة لمرة وحدة) ويرجّع رابط الدفع
    webhook/route.ts               ← POST: يستقبل أحداث الاشتراك من Lemon Squeezy،
                                     يتحقق من التوقيع (HMAC)، يحدّث جدول subscribers
    check-subscription/route.ts    ← POST: يستقبل إيميل، يتحقق من الاشتراك الفعّال
                                     بقاعدة البيانات، يرجّع القائمة الكاملة لو فعّال

lib/
  deals.ts                        ← بيانات الخصومات (mock) + حقل free/paid
  db.ts                            ← طبقة قاعدة بيانات (SQLite محلياً / Postgres بالإنتاج)
                                     جدول واحد: subscribers
  lemonsqueezy.ts                  ← دوال مساعدة: إنشاء checkout + التحقق من توقيع الـ webhook

.env.example                       ← قائمة متغيرات البيئة المطلوبة
package.json                       ← الاعتماديات (بدون Redux/GraphQL/Prisma)
README.md                          ← خطوات الإعداد والنشر كاملة (من الجوال)
```

## تدفق العملية (Flow)

1. المستخدم يزور `/` → يشوف عينة مجانية + قائمة مقفولة (blurred).
2. يضغط "اشترك الآن" → `POST /api/checkout` → يتحول لصفحة دفع Lemon Squeezy.
3. بعد الدفع → Lemon Squeezy يرسل حدث `subscription_created` إلى
   `POST /api/webhook` → يتحقق من التوقيع → يحفظ الإيميل بجدول `subscribers`
   بحالة `active`.
4. Lemon Squeezy يحوّل المستخدم إلى `/success`.
5. المستخدم يرجع للصفحة الرئيسية، يدخل نفس الإيميل، يضغط "تحقق من اشتراكي"
   → `POST /api/check-subscription` → لو فعّال يرجّع القائمة الكاملة بالروابط
   المباشرة وتظهر بالواجهة.

## نقاط توسّع مستقبلية (خارج الـ Scope الحالي)

- تسجيل دخول حقيقي (magic link) بدل إدخال الإيميل يدوياً بكل زيارة.
- مصدر بيانات ديناميكي للخصومات بدل ملف `deals.ts` الثابت.
- صفحة إدارة (admin) لإضافة/تعديل الخصومات بدون رفع كود جديد.
